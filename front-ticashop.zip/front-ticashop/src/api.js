const API_URL = 'http://localhost:8000/api';

// ====== PRODUCTOS ======
export async function getProductos() {
  const res = await fetch(`${API_URL}/productos/`);
  if (!res.ok) throw new Error('Error al obtener productos');
  return res.json();
}

export async function getProducto(id) {
  const res = await fetch(`${API_URL}/productos/${id}/`);
  if (!res.ok) throw new Error('Error al obtener producto');
  return res.json();
}

export async function crearProducto(producto) {
  const res = await fetch(`${API_URL}/productos/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(producto),
  });
  if (!res.ok) throw new Error('Error al crear producto');
  return res.json();
}

export async function actualizarProducto(id, producto) {
  const res = await fetch(`${API_URL}/productos/${id}/`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(producto),
  });
  if (!res.ok) throw new Error('Error al actualizar producto');
  return res.json();
}

export async function deleteProducto(id) {
  const res = await fetch(`${API_URL}/productos/${id}/`, {
    method: 'DELETE',
  });
  if (!res.ok) throw new Error('Error al eliminar producto');
}

// ====== PROVEEDORES ======
export async function getProveedores() {
  const res = await fetch(`${API_URL}/proveedores/`);
  if (!res.ok) throw new Error('Error al obtener proveedores');
  return res.json();
}

export async function getProveedor(id) {
  const res = await fetch(`${API_URL}/proveedores/${id}/`);
  if (!res.ok) throw new Error("Error al obtener proveedor");
  return res.json();
}

export async function crearProveedor(data) {
  const res = await fetch(`${API_URL}/proveedores/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Error al crear proveedor");
  return res.json();
}

export async function actualizarProveedor(id, data) {
  const res = await fetch(`${API_URL}/proveedores/${id}/`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Error al actualizar proveedor");
  return res.json();
}

export async function deleteProveedor(id) {
  const res = await fetch(`${API_URL}/proveedores/${id}/`, {
    method: "DELETE",
  });
  if (!res.ok) throw new Error("Error al eliminar proveedor");
}

// ====== MOVIMIENTOS DE INVENTARIO ======

// Obtener TODOS los movimientos
export async function getMovimientos() {
  const res = await fetch(`${API_URL}/movimientos/`);
  if (!res.ok) throw new Error("Error al obtener movimientos de inventario");
  return res.json();
}

// Obtener UN movimiento por id (para editar)
export async function getMovimiento(id) {
  const res = await fetch(`${API_URL}/movimientos/${id}/`);
  if (!res.ok) throw new Error("Error al obtener movimiento de inventario");
  return res.json();
}

// Crear movimiento
export async function crearMovimiento(data) {
  const res = await fetch(`${API_URL}/movimientos/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Error al crear movimiento");
  return res.json();
}

// Actualizar movimiento
export async function actualizarMovimiento(id, data) {
  const res = await fetch(`${API_URL}/movimientos/${id}/`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Error al actualizar movimiento");
  return res.json();
}

// Eliminar movimiento
export async function deleteMovimiento(id) {
  const res = await fetch(`${API_URL}/movimientos/${id}/`, {
    method: "DELETE",
  });
  if (!res.ok) throw new Error("Error al eliminar movimiento de inventario");
}