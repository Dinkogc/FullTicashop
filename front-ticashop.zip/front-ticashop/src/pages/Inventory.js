import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  getMovimientos,
  deleteMovimiento,
  getProveedores,
  getProductos,
} from "../api";

export default function Inventory({ user }) {
  const [ingresos, setIngresos] = useState([]);
  const [proveedores, setProveedores] = useState({}); // 👈 usamos diccionario
  const [productos, setProductos] = useState({});     // 👈 usamos diccionario

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Cargar movimientos, proveedores y productos desde el backend
  useEffect(() => {
    async function fetchData() {
      try {
        const [movs, provs, prods] = await Promise.all([
          getMovimientos(),
          getProveedores(),
          getProductos(),
        ]);

        // Adaptar proveedores y productos a diccionarios para buscar rápido
        const proveedoresMap = provs.reduce((acc, p) => {
          acc[p.id] = p;
          return acc;
        }, {});

        const productosMap = prods.reduce((acc, p) => {
          acc[p.id] = p;
          return acc;
        }, {});

        // Mapear movimientos a la estructura que usa la tabla
        const mappedMovs = movs.map((m) => {
          const prod = productosMap[m.producto] || {};

          return {
            id: m.id,
            productId: m.producto, // id del producto
            // proveedor sale del producto
            proveedorId: prod.proveedor || null,
            // categoría: como no hay en el modelo, dejamos "—"
            categoria: "—",
            // descripción del producto
            descripcion: prod.descripcion || "",
            cantidad: m.cantidad,
            // precio viene del movimiento o, si faltara, del producto
            precio: m.precioUnitario ?? prod.precioUnitario,
            // total calculado si no viene desde el backend
            total:
              m.total ??
              m.cantidad *
                Number(m.precioUnitario ?? prod.precioUnitario ?? 0),
            fecha: m.fecha,
          };
        });

        // 👇 Guardar en estado los diccionarios y los movimientos mapeados
        setProveedores(proveedoresMap);
        setProductos(productosMap);
        setIngresos(mappedMovs);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setError("Error al cargar el inventario");
        setLoading(false);
      }
    }

    fetchData();
  }, []);

  // Helpers para mostrar nombres
  function getProveedorName(id) {
    if (!id) return "—";
    return proveedores[id]?.nombre || "—";
  }

  function getProductName(id) {
    if (!id) return "—";
    return productos[id]?.nombre || "—";
  }

  async function remove(id) {
    if (user?.role !== "administrador") {
      alert("Solo administradores pueden eliminar ingresos.");
      return;
    }
    if (!window.confirm("¿Eliminar ingreso de inventario?")) return;

    try {
      await deleteMovimiento(id); // eliminar en backend
      setIngresos(ingresos.filter((i) => i.id !== id)); // actualizar tabla
    } catch (err) {
      console.error(err);
      alert("No se pudo eliminar el ingreso");
    }
  }

  if (loading) {
    return <div>Cargando inventario...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div>
      <div className="page-header">
        <h2>Inventario</h2>
        {(user?.role === "administrador" || user?.role === "operario") && (
          <Link to="/inventory/new" className="btn-primary">
            Nuevo ingreso
          </Link>
        )}
      </div>

      {ingresos.length === 0 ? (
        <div className="empty-message">No hay ingresos registrados</div>
      ) : (
        <table className="report-table">
          <thead>
            <tr>
              <th>Producto</th>
              <th>Categoría</th>
              <th>Proveedor</th>
              <th>Descripción</th>
              <th>Cantidad</th>
              <th>Precio Unitario</th>
              <th>Total</th>
              <th>Fecha</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {ingresos.map((i) => (
              <tr key={i.id}>
                <td>{getProductName(i.productId)}</td>
                <td>{i.categoria}</td>
                <td>{getProveedorName(i.proveedorId)}</td>
                <td>{i.descripcion}</td>
                <td>{i.cantidad}</td>
                <td>${Number(i.precio).toLocaleString("es-CL")}</td>
                <td>${Number(i.total).toLocaleString("es-CL")}</td>
                <td>{i.fecha}</td>
                <td>
                  <Link to={`/inventory/edit/${i.id}`} className="link">
                    Editar
                  </Link>{" "}
                  |{" "}
                  {user?.role === "administrador" && (
                    <button
                      onClick={() => remove(i.id)}
                      className="danger"
                      style={{ padding: "4px 8px" }}
                    >
                      Eliminar
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}