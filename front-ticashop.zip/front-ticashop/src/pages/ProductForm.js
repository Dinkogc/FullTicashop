import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "../FormStyles.css"; 

import {
  crearProducto,
  actualizarProducto,
  getProducto,
  getProveedores,
} from "../api";

export default function ProductForm({ user }) {
  const { id } = useParams();
  const navigate = useNavigate();

  const esEdicion = Boolean(id);

  const [proveedores, setProveedores] = useState([]);

  const [formData, setFormData] = useState({
    codigo: `PRD-${Date.now().toString().slice(-5)}`,
    nombre: "",
    categoria: "",
    precioUnitario: "",
    fechaIngreso: "",
    stockActual: 0,
    proveedor: "",
  });

  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState(null);

  // PROTEGER LA RUTA
  useEffect(() => {
    if (!user) navigate("/login");
  }, [user, navigate]);

  // CARGAR PROVEEDORES Y PRODUCTO (SI EDITA)
  useEffect(() => {
    async function cargar() {
      try {
        const provs = await getProveedores();
        setProveedores(provs);

        if (esEdicion) {
          const producto = await getProducto(id);

          setFormData({
            codigo: producto.codigo,
            nombre: producto.nombre,
            categoria: producto.categoria || "",
            precioUnitario: producto.precioUnitario,
            fechaIngreso: producto.fechaIngreso,
            stockActual: producto.stockActual,
            proveedor: producto.proveedor,
          });
        }
      } catch (err) {
        setError("Error al cargar el formulario");
      } finally {
        setCargando(false);
      }
    }

    cargar();
  }, [esEdicion, id]);

  function handleChange(e) {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setGuardando(true);
    setError(null);

    const payload = {
      codigo: formData.codigo,
      nombre: formData.nombre,
      categoria: formData.categoria,
      precioUnitario: Number(formData.precioUnitario),
      fechaIngreso: formData.fechaIngreso,
      stockActual: Number(formData.stockActual),
      proveedor: Number(formData.proveedor),
    };

    try {
      if (esEdicion) {
        await actualizarProducto(id, payload);
      } else {
        await crearProducto(payload);
      }

      navigate("/products");

    } catch (err) {
      setError("Error al guardar el producto");
    } finally {
      setGuardando(false);
    }
  }

  if (cargando) return <div>Cargando...</div>;

  return (
    <div className="form-container">
      <h2>{esEdicion ? "Editar producto" : "Nuevo producto"}</h2>

      {error && <div className="error-message">{error}</div>}

      <form onSubmit={handleSubmit} className="responsive-form">
        
        <div className="form-group">
          <label>Código</label>
          <input type="text" value={formData.codigo} disabled />
        </div>

        <div className="form-group">
          <label>Nombre</label>
          <input
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Categoría</label>
          <select
            name="categoria"
            value={formData.categoria}
            onChange={handleChange}
            required
          >
            <option value="">-- Seleccione --</option>
            <option value="Electrónica">Electrónica</option>
            <option value="Computación">Computación</option>
            <option value="Accesorios">Accesorios</option>
            <option value="Otros">Otros</option>
          </select>
        </div>

        <div className="form-group">
          <label>Precio</label>
          <input
            type="number"
            name="precioUnitario"
            value={formData.precioUnitario}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Fecha ingreso</label>
          <input
            type="date"
            name="fechaIngreso"
            value={formData.fechaIngreso}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Proveedor</label>
          <select
            name="proveedor"
            value={formData.proveedor}
            onChange={handleChange}
            required
          >
            <option value="">-- Seleccione proveedor --</option>
            {proveedores.map((p) => (
              <option key={p.id} value={p.id}>
                {p.nombre}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>Stock inicial</label>
          <input
            type="number"
            name="stockActual"
            value={formData.stockActual}
            onChange={handleChange}
            min="0"
            required
          />
        </div>

        <div className="button-container">
          <button type="submit" className="submit-btn" disabled={guardando}>
            {guardando ? "Guardando..." : "Guardar producto"}
          </button>
        </div>
      </form>
    </div>
  );
}