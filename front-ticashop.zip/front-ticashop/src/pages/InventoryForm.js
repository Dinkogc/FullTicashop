import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "../FormStyles.css";

import {
  getProductos,
  getProveedores,
  getMovimiento,
  crearMovimiento,
  actualizarMovimiento,
} from "../api";

export default function InventoryForm({ user }) {
  const { id } = useParams();
  const nav = useNavigate();
  const esEdicion = Boolean(id);

  const [productos, setProductos] = useState([]);
  const [proveedores, setProveedores] = useState([]);

  const [productId, setProductId] = useState("");
  const [supplierId, setSupplierId] = useState("");
  const [quantity, setQuantity] = useState(0);
  const [date, setDate] = useState("");
  const [notes, setNotes] = useState("");

  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState(null);

  // Proteger la ruta si no hay usuario
  useEffect(() => {
    if (!user) nav("/login");
  }, [user, nav]);

  // Cargar productos, proveedores y movimiento (si se edita)
  useEffect(() => {
    async function cargarDatos() {
      try {
        const [prods, provs] = await Promise.all([
          getProductos(),
          getProveedores(),
        ]);

        setProductos(prods);
        setProveedores(provs);

        if (esEdicion) {
          const mov = await getMovimiento(id);
          setProductId(mov.producto || "");      // FK al producto
          setSupplierId(mov.proveedor || "");    // FK al proveedor (si existe)
          setQuantity(mov.cantidad || 0);
          setDate(mov.fecha ? mov.fecha.slice(0, 10) : ""); // yyyy-mm-dd
          setNotes(mov.descripcion || "");
        }

        setCargando(false);
      } catch (err) {
        console.error(err);
        setError("Error al cargar los datos del formulario");
        setCargando(false);
      }
    }

    cargarDatos();
  }, [esEdicion, id]);

  async function submit(e) {
    e.preventDefault();
    setGuardando(true);
    setError(null);

    const payload = {
      producto: Number(productId),
      proveedor: supplierId ? Number(supplierId) : null,
      cantidad: Number(quantity),
      fecha: date,
      observacion: notes,
      tipoMovimiento: "ENTRADA", // este formulario registra ingresos
    };

    try {
      if (esEdicion) {
        await actualizarMovimiento(id, payload);
      } else {
        await crearMovimiento(payload);
      }

      nav("/inventory");
    } catch (err) {
      console.error(err);
      setError("Error al guardar el ingreso de inventario");
    } finally {
      setGuardando(false);
    }
  }

  if (cargando) {
    return <div>Cargando formulario de inventario...</div>;
  }

  return (
    <div className="card max-w">
      <h2>{esEdicion ? "Editar ingreso de inventario" : "Nuevo ingreso"}</h2>

      {error && <div className="error-message">{error}</div>}

      <form onSubmit={submit}>
        <label>Producto</label>
        <select
          value={productId}
          onChange={(e) => setProductId(e.target.value)}
          required
        >
          <option value="">-- Seleccione un producto --</option>
          {productos.map((p) => (
            <option key={p.id} value={p.id}>
              {p.nombre}
            </option>
          ))}
        </select>

        <label>Proveedor</label>
        <select
          value={supplierId}
          onChange={(e) => setSupplierId(e.target.value)}
        >
          <option value="">-- Seleccione un proveedor --</option>
          {proveedores.map((s) => (
            <option key={s.id} value={s.id}>
              {s.nombre}
            </option>
          ))}
        </select>

        <label>Cantidad ingresada</label>
        <input
          type="number"
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
          placeholder="Ej: 25"
          min="1"
          required
        />

        <label>Fecha</label>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
        />

        <label>Notas</label>
        <textarea
          rows="3"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Ej: Lote recibido sin daños"
        ></textarea>

        <div style={{ textAlign: "right" }}>
          <button className="primary" disabled={guardando}>
            {guardando ? "Guardando..." : "Guardar"}
          </button>
        </div>
      </form>
    </div>
  );
}