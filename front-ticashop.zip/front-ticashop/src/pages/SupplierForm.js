import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "../FormStyles.css";

import {
  getProveedor,
  crearProveedor,
  actualizarProveedor,
} from "../api";

export default function SupplierForm({ user }) {
  const { id } = useParams();
  const nav = useNavigate();
  const esEdicion = Boolean(id);

  const [name, setName] = useState("");
  const [rut, setRut] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState(null);

  // Proteger ruta
  useEffect(() => {
    if (!user) nav("/login");
  }, [user, nav]);

  // Cargar proveedor si estamos editando
  useEffect(() => {
    async function cargar() {
      try {
        if (esEdicion) {
          const proveedor = await getProveedor(id);
          setName(proveedor.nombre || "");
          setRut(proveedor.rut || "");
          setEmail(proveedor.email || "");
          setPhone(proveedor.telefono || "");
          setAddress(proveedor.direccion || "");
        }
      } catch (err) {
        console.error(err);
        setError("Error al cargar proveedor");
      } finally {
        setCargando(false);
      }
    }

    cargar();
  }, [esEdicion, id]);

  async function submit(e) {
    e.preventDefault();
    setGuardando(true);
    setError(null);

    // Objeto con nombres de campos como en el modelo Django
    const payload = {
      nombre: name,
      rut: rut,
      email: email,
      telefono: phone,
      direccion: address,
    };

    try {
      if (esEdicion) {
        await actualizarProveedor(id, payload);
      } else {
        await crearProveedor(payload);
      }

      nav("/suppliers");
    } catch (err) {
      console.error(err);
      setError("Error al guardar proveedor");
    } finally {
      setGuardando(false);
    }
  }

  if (cargando) {
    return <div>Cargando...</div>;
  }

  return (
    <div className="card max-w">
      <h2>{esEdicion ? "Editar proveedor" : "Nuevo proveedor"}</h2>

      {error && <div className="error-message">{error}</div>}

      <form onSubmit={submit}>
        <label>Nombre</label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Ej: Proveedor ABC Ltda."
          required
        />

        <label>RUT</label>
        <input
          value={rut}
          onChange={(e) => setRut(e.target.value)}
          placeholder="Ej: 76.123.456-7"
          required
        />

        <label>Correo electrónico</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="correo@ejemplo.com"
          required
        />

        <label>Teléfono</label>
        <input
          type="tel"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          placeholder="+56 9 8765 4321"
        />

        <label>Dirección</label>
        <input
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="Ej: Av. Las Flores 123, Santiago"
        />

        <div style={{ textAlign: "right" }}>
          <button className="primary" disabled={guardando}>
            {guardando ? "Guardando..." : "Guardar"}
          </button>
        </div>
      </form>
    </div>
  );
}