import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getProductos, deleteProducto } from "../api";

export default function Products({ user }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Cargar productos desde el backend al montar el componente
  useEffect(() => {
    async function fetchData() {
      try {
        const data = await getProductos();

        // Aquí mapeamos los campos del backend a los que usa el frontend
        // Suponiendo modelo Django: codigo, nombre, precioUnitario, stockActual
        const mapped = data.map((p) => ({
          id: p.id,
          name: p.nombre,
          code: p.codigo,
          category: p.categoria || "—",       // si no tienes categoría, puedes dejar "—"
          price: p.precioUnitario,
          date: p.fecha_ingreso || "—",      // si no existe, "—"
          stock: p.stockActual,
        }));

        setProducts(mapped);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setError("Error al cargar productos");
        setLoading(false);
      }
    }

    fetchData();
  }, []);

  async function remove(id) {
    if (user?.role !== "administrador") {
      alert("Solo administradores pueden eliminar productos.");
      return;
    }
    if (!window.confirm("¿Eliminar producto?")) return;

    try {
      // primero eliminar en el backend
      await deleteProducto(id);
      // luego actualizar el estado en el frontend
      setProducts(products.filter((p) => p.id !== id));
    } catch (err) {
      console.error(err);
      alert("No se pudo eliminar el producto");
    }
  }

  if (loading) {
    return <div>Cargando productos...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div>
      <div className="page-header">
        <h2>Productos</h2>
        {(user?.role === "administrador" || user?.role === "operario") && (
          <Link to="/products/new" className="btn-primary">
            Nuevo producto
          </Link>
        )}
      </div>

      {products.length === 0 ? (
        <div className="empty-message">No hay productos registrados</div>
      ) : (
        <div className="product-list">
          {products.map((p) => (
            <div className="product-card" key={p.id}>
              <h3>{p.name}</h3>
              <div><strong>Código:</strong> {p.code}</div>
              <div><strong>Categoría:</strong> {p.category || "—"}</div>
              <div>
                <strong>Precio:</strong>{" "}
                {p.price ? `$${p.price.toLocaleString("es-CL")}` : "—"}
              </div>
              <div><strong>Fecha ingreso:</strong> {p.date || "—"}</div>
              <div><strong>Stock:</strong> {p.stock || 0}</div>

              <div className="card-actions">
                <Link to={`/products/edit/${p.id}`} className="link">
                  Editar
                </Link>
                {user?.role === "administrador" && (
                  <button onClick={() => remove(p.id)} className="danger">
                    Eliminar
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}