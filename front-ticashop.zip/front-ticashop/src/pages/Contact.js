import React from "react";

function Contact() {
  return (
    <main>
      <h2>Contacto</h2>
      <p>Correo: contacto@mitienda.com</p>
      <p>Teléfono: +56 9 1234 5678</p>
    </main>
  );
}

export default Contact;