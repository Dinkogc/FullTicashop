import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
// Ya no usamos localStorage
// import { load, save } from "../lib/store";
import { getProveedores, deleteProveedor } from "../api";

export default function Suppliers({ user }) {
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Cargar proveedores desde Django cuando se monta el componente
  useEffect(() => {
    async function fetchData() {
      try {
        const data = await getProveedores();

        // Adaptar campos del backend a los que usa el frontend
        const mapped = data.map((p) => ({
          id: p.id,
          name: p.nombre,
          rut: p.rut || "—",
          email: p.email || "—",
          phone: p.telefono || "—",
          address: p.direccion || "—",
          // Si en tu modelo no tienes estos campos, los dejamos en "—"
          category: p.categoria || "—",
          date: p.fechaRegistro || "—",
        }));

        setSuppliers(mapped);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setError("Error al cargar proveedores");
        setLoading(false);
      }
    }

    fetchData();
  }, []);

  async function remove(id) {
    if (user?.role !== "administrador") {
      alert("Solo los administradores pueden eliminar proveedores.");
      return;
    }
    if (!window.confirm("¿Eliminar proveedor?")) return;

    try {
      await deleteProveedor(id);             // Eliminar en backend
      setSuppliers(suppliers.filter((s) => s.id !== id)); // Actualizar lista
    } catch (err) {
      console.error(err);
      alert("No se pudo eliminar el proveedor");
    }
  }

  if (loading) {
    return <div>Cargando proveedores...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div>
      <div className="page-header">
        <h2>Proveedores</h2>
        {(user?.role === "administrador" || user?.role === "operario") && (
          <Link to="/suppliers/new" className="btn-primary">
            Nuevo proveedor
          </Link>
        )}
      </div>

      {suppliers.length === 0 ? (
        <div className="empty-message">No hay proveedores registrados</div>
      ) : (
        <div className="product-list">
          {suppliers.map((s) => (
            <div className="product-card" key={s.id}>
              <h3>{s.name}</h3>
              <div className="product-info">
                <div><strong>RUT:</strong> {s.rut}</div>
                <div><strong>Email:</strong> {s.email}</div>
                <div><strong>Teléfono:</strong> {s.phone}</div>
                <div><strong>Dirección:</strong> {s.address}</div>
                <div><strong>Categoría:</strong> {s.category}</div>
                <div><strong>Fecha de registro:</strong> {s.date}</div>
              </div>

              <div className="card-actions">
                <Link to={`/suppliers/edit/${s.id}`} className="link">
                  Editar
                </Link>
                {user?.role === "administrador" && (
                  <button onClick={() => remove(s.id)} className="danger">
                    Eliminar
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}