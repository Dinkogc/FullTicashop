import React from "react";

function Footer() {
  return (
    <footer>
      <p>© 2025 TICASHOP LATAM - Todos los derechos reservados</p>
    </footer>
  );
}


export default Footer;
